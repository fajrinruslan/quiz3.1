<form action="" method="post" enctype="multipart/form-data"> <!---untuk nambah foto-->
	<p>id pengguna  
		&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp;
		<input type="text" name="id"></p>
	<p>nama pengguna 
		&nbsp
		<input type="text" name="nama_pengguna"></p>
	<p>deskripsi 
		&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp;
		<input type="text" name="deskripsi"></p>
	<p>nomer handphone 
		&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp;
		<input type="text" name="nomer_hp"></p>
	<p>nomer loker pengguna 
		&nbsp&nbsp;
		<input type="text" name="nomer_loker"></p>
	<p>waktu 
		&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp;
		<input type="text" name="waktu_pengambilan"></p>		
	<p><input type="submit" value="oke " name="tambah"></p>
</form>
</form>

<?php
 
	require('koneksi_kuiz.php');//memanggil koneksi database atau require(jika filenya gak ada maka akan error)bisa juga dengan include
	
	if($_SERVER['REQUEST_METHOD']=='POST'){
	$nama_pengguna = $_POST['nama_pengguna'];
	$deskripsi = $_POST['deskripsi'];
	$nomer_hp  = $_POST['nomer_hp'];
	$nomer_loker  = $_POST['nomer_loker'];
	$waktu_pengambilan  = $_POST['waktu_pengambilan'];
	
	$sql="insert into pengguna(nama_pengguna,deskripsi,nomer_hp,nomer_loker,waktu_pengambilan)values
	('$nama_pengguna', $deskripsi, $nomer_hp, $nomer_loker, $waktu_pengambilan)";
	
	mysqli_query($con, $sql) or die('gagal'.mysqli_error($con));
	
	header('location:index.php');
	
	
	}
 ?>