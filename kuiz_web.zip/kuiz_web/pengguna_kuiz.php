<form action="" method="post" enctype="multipart/form-data"> <!---untuk nambah foto-->
	<p>id pengguna  
		&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp;
		<input type="text" name="id"></p>
	<p>nama pengguna 
		&nbsp
		<input type="text" name="nama_pengguna"></p>
	<p>deskripsi 
		&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp;
		<input type="text" name="deskripsi"></p>
	<p>nomer handphone 
		&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp;
		<input type="text" name="nomer_hp"></p>
	<p>nomer loker pengguna 
		&nbsp&nbsp;
		<input type="text" name="nomer_loker"></p>
	<p>waktu 
		&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp;
		<input type="text" name="waktu_pengambilan"></p>		
	<p><input type="submit" value="oke " name="tambah"></p>
</form>

 
