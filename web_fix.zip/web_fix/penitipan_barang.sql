-- phpMyAdmin SQL Dump
-- version 4.1.6
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 14, 2014 at 04:35 PM
-- Server version: 5.6.16
-- PHP Version: 5.5.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `penitipan_barang`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `nama_admin` varchar(20) NOT NULL,
  `paswd_admin` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`nama_admin`, `paswd_admin`) VALUES
('fajrin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `pengguna`
--

CREATE TABLE IF NOT EXISTS `pengguna` (
  `id_pengguna` varchar(10) NOT NULL,
  `nama_pengguna` varchar(20) NOT NULL,
  `deskripsi` varchar(30) NOT NULL,
  `no_hp_pengguna` int(20) NOT NULL,
  `no_loker` int(10) NOT NULL,
  `waktu_penitipan` time NOT NULL,
  `waktu_akhir` time NOT NULL,
  `biaya` int(11) NOT NULL,
  `status` varchar(20) NOT NULL,
  PRIMARY KEY (`id_pengguna`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pengguna`
--

INSERT INTO `pengguna` (`id_pengguna`, `nama_pengguna`, `deskripsi`, `no_hp_pengguna`, `no_loker`, `waktu_penitipan`, `waktu_akhir`, `biaya`, `status`) VALUES
('A1', 'yanto', 'sendal', 856565656, 321, '10:33:04', '15:31:20', 4, '4000'),
('B4', 'afifi', 'bapak nya', 2147483647, 123, '15:14:10', '00:00:00', 0, ''),
('C3', 'wahyu', 'laptop', 85656564, 456, '15:32:48', '00:00:00', 0, '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
