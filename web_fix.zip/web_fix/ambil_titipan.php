<!DOCTYPE html>
<html>
	<head>
		<title>Ambil barang</title>
	</head>
	<body>
		<form action = "proses_ambil_titipan.php" method = "post" encytpe = "multipart/form-data">
		<table align = "left"; margin = "100">
			<tr>
				<td><h1>Halaman Pengambilan Barang</h1></td>
			</tr>

			<tr>
				<td align = "left">Masukkan Nomer Penitipan Anda : </td>
				<td align = "left"><input type = "text" name = "id_pengguna"></td>
			</tr>

			<tr>
				<td align = "left"><input type = "submit" name = "ok" value = "     OK     "></td>
			</tr>

			<tr>
				<td><a href = "menu_utama.php"><- Kembali ke Menu Daftar Penitipan Barang</a></td>
			</tr>
			
		</table>
		</form>	
	</body>
</html>