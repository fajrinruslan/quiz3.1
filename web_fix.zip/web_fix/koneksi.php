<?php 
	$host  = 'localhost';
	$dbname = 'penitipan_barang';
	$user = 'root';
	$pass = '';

	$con = mysqli_connect($host, $user, $pass, $dbname);
	if(mysqli_connect_errno()){
		echo "TIDAK BERHASIL MELAKUKAN KONEKSI : ".mysqli_connect_error();
	}
?>