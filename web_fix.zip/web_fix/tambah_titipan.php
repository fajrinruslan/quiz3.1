<form action = " " method = "post" enctype = "multipart/form-data">
	<table align = "left" ; margin = "100">
		<tr>
			<td><h2>Tambah Data Barang</h2></td>
		</tr>	
		<tr>
			<td align = "left">ID Pengguna : </td>
			<td align = "left"><input type = "text" name = "id_pengguna"</td>
		</tr>

		<tr>
			<td align = "left">Nama Pengguna : </td>
			<td align = "left"><input type = "text" name = "nama_pengguna"</td>
		</tr>

		<tr>
			<td align = "left">Deskripsi  : </td>
			<td align = "left"><input type = "text" name = "deskripsi"</td>
		</tr>

		<tr>
			<td align = "left">Nomer HP : </td>
			<td align = "left"><input type = "text" name = "no_hp_pengguna"</td>
		</tr>

		<tr>
			<td align = "left">Nomer Loker : </td>
			<td align = "left"><input type = "text" name = "no_loker"</td>
		</tr>

		<tr>
			<td align = "left"><input type = "submit" value = "   OK   "></td>
		<tr>

		<tr>
			<td> 
				<a href="menu_utama.php"><- Kembali ke Menu Daftar Penitipan Barang</a>
			</td>		
		</tr>

	</table>
</form>

<?php
	require ('koneksi.php');

	if ($_SERVER['REQUEST_METHOD'] == 'POST') {
		# code...
		$id_p = $_POST['id_pengguna'];
		$nama_p = $_POST['nama_pengguna'];
		$descr = $_POST['deskripsi'];
		$no_hp = $_POST['no_hp_pengguna'];
		$no_l = $_POST['no_loker'];
		//$jam = $_POST['waktu_penitipan'];
	
		$sql = "insert into pengguna(id_pengguna, nama_pengguna,deskripsi,no_hp_pengguna,no_loker,waktu_penitipan) 
		values('$id_p' , '$nama_p' , '$descr', $no_hp , $no_l , now() )";

		mysqli_query($con , $sql) or die('tidak berhasil' .mysqli_error($con)); 
	}
?>
</body>
</html>