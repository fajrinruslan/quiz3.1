<!DOCTYPE html>
<html>
	<head>
	<title>login admin</title>	
	</head>

	<body background = "ugm.png">
		<h1 align = "center">--- FORM LOGIN ADMIN ---</h1>
		<form action = ""   method="post">
			<p align = "center">Username 
				<input type = "text" name = "nama_admin">
			</p>
			<p align = "center">Password 
				<input type = "password" name = "paswd_admin">
			</p>
			<p align = "center"><input type = "submit" name = "submit" value = "        enter        "></p>
		</form>	
<?php
	session_start();
	require ('koneksi.php');
	if ($_SERVER['REQUEST_METHOD'] == "POST") {
		# code...
		$sql = "select *from admin where nama_admin = '".$_POST['nama_admin']."' 
		and paswd_admin = '".$_POST['paswd_admin']."'";

		$query =mysqli_query($con, $sql) or die (mysqli_error($con));
		if (mysqli_num_rows($query)) {
			# code...
			while ($row = mysqli_fetch_assoc($query)) {
				# code...
				$_SESSION['login'] = 1;
				$_SESSION['Username'] = $row['paswd_admin'];

				echo "Berhasil login";
				header ('location:menu_utama.php');
			}
		}
		else {
			echo "Username atau Password yang anda masukkan salah";
		}
	}
?>
	</body>
</html>