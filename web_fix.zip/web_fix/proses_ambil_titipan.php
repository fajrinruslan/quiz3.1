<!DOCTYPE html>
<html>
<head>
	<title>proses pengambilan</title>
</head>
<body>
	<h1>Proses Pengambilan Barang</h1>
	<a href="ambil_titipan.php">Kembali ke Halaman Pengambilan Barang || </a>
	<a href="menu_utama.php">			Kembali ke Menu Daftar Penitipan Barang</a>
<?php
	require ('koneksi.php');

	if ($_SERVER['REQUEST_METHOD'] == 'POST') {
		# code...
		$no_transaksi = $_POST['id_pengguna'];	
	
	$sql = "update pengguna set waktu_akhir = now() , 
			biaya = (select timestampdiff(Hour, waktu_penitipan, waktu_akhir)) , status = (biaya*1000)
			where id_pengguna = '$no_transaksi'";

			mysqli_query($con , $sql) or die('Gagal!!!'.mysqli_error($con));
	}
?>

<?php 
	require ('koneksi.php');
	if ($_SERVER['REQUEST_METHOD'] == 'POST') {
		# code...
		$query = mysqli_query($con , "select * from pengguna where id_pengguna = '$no_transaksi'") or die (mysqli_error($con));
		while ($data = mysqli_fetch_assoc($query)) {
			# code...
			
			echo "<table border = '3'>
			
			<tr>";
			echo "<th>ID Pengguna</th>";
			echo "<th>Nama Pengguna</th>";
			echo "<th>Nama Barang Titipan</th>";
			echo "<th>Nomer HP</th>";
			echo "<th>Nomer Loker</th>";
			echo "<th>Waktu Penitipan Barang</th>";
			echo "<th>Waktu Pengambilan Barang</th>";
			echo "<th>Total Pembayaran</th>";
			echo "</tr>";

			echo 
			"<tr>";
			echo "<td>".$data['id_pengguna']."</td>";
			echo "<td>".$data['nama_pengguna']."</td>";
			echo "<td>".$data['deskripsi']."</td>";
			echo "<td>".$data['no_hp_pengguna']."</td>";
			echo "<td>".$data['no_loker']."</td>";
			echo "<td>".$data['waktu_penitipan']."</td>";
			echo "<td>".$data['waktu_akhir']."</td>";
			echo "<td>".$data['status']."</td>";
			
			echo "</table>";
			echo "<a href='delete.php?&id_pengguna=".$data['id_pengguna']."'>Hapus</a>";
		}
	}
?></td>
</body>
</html>