<html>
<head>
	<title></title>
</head>
</html>
<?php 
	$host = 'localhost';
	$dbname = 'penitipan_barang';
	$user = 'root';
	$pass = '';

	$con = mysqli_connect($host, $user, $pass, $dbname);
	if(mysqli_connect_errno()){
		echo "TIDAK BERHASIL MELAKUKAN KONEKSI : ".mysqli_connect_error();
	}

	if(isset($_GET['id_pengguna'])){
		$sql = "delete from pengguna where id_pengguna ='".$_GET['id_pengguna']."'";
		$query = mysqli_query($con , $sql);	

		if (!$query) {
			# code...
			echo mysqli_error($con);
		}else{
			echo "Alhamdulillah data berhasil di hapus";
			echo "<a href =\"menu_utama.php\">Kembali ke Menu Daftar Penitipan Barang</a>";
		}
	}
?>