<?php
	session_start();
	session_destroy();
	header('location : cek_login.php');
?>