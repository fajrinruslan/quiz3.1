<html>
	<head>
		<title>menu</title>
	</head>
	<body> 
<?php 
	//membuat koneksi terlebih dahulu
	$host  = 'localhost';
	$dbname = 'penitipan_barang';
	$user = 'root';
	$pass = '';

	$con = mysqli_connect($host, $user, $pass ,$dbname);
	if(mysqli_connect_errno()){
		echo "TIDAK BERHASIL MELAKUKAN KONEKSI". mysqli_connect_error();
	}
	else{
		echo "";
	}

	//untuk koneksi database dengan php
	$query = mysqli_query($con, "select * from pengguna");
	echo  "" 
?>
<h1 align = "center"> MENU DAFTAR PENITIPAN BARANG </h1>
	<!--tambah barang-->
	<a href = "tambah_titipan.php "> 
		<p align = "center">   
		<input type = "submit" name = "submit" value = "Tambah data penitipan">
		</p> 
	</a>
	<!--ambil barang-->
	<a href="ambil_titipan.php">  
		<p align = "center">   
		<input type = "submit" name = "submit" value = "      Ambil penitipan      ">
		</p> 	
	</a>
	<!--keluar-->
	<a href="cek_login.php">  
		<p align = "center">   
		<input type = "submit" name = "submit" value = "             Logout             ">
		</p> 	
	</a>

	<!--membuat table--> 

	<br>
	<table align = "center" border = "3">
	</br>
	<tr>
		<th>Nomer</th>
		<th>Nama Pelanggan</th>
		<th>Deskripsi Barang</th>
		<th>Nomer HP</th>
		<th>Nomer Loker</th>
		<th>Waktu Penitipan</th>
	</tr>

<?php 
	while ($row = mysqli_fetch_array($query)) {
		echo "<tr>";
		echo "<td>" .$row['id_pengguna']."</td>";
		echo "<td>" .$row['nama_pengguna']."</td>";
		echo "<td>" .$row['deskripsi']."</td>";
		echo "<td>" .$row['no_hp_pengguna']."</td>";
		echo "<td>" .$row['no_loker']."</td>";
		echo "<td>" .$row['waktu_penitipan']."</td>";
		echo "</tr>";
	}
?>	
</table>